# St. James High School — Student Behavior Tracker (Phase 3)

Phase 3 upgrades the real PWA with a school-branded dashboard and positive-behaviour workflow.

## Included
- Supabase Auth login and role-aware access.
- St. James High School crest/branding.
- Dashboard redesigned around the approved dashboard concept.
- Live summary cards for students, today's infractions, active suspensions, monthly referrals and positive behaviour.
- Recent activity feed covering infractions, suspensions, referrals and positive behaviour.
- Behaviour overview and students-by-grade visual summaries.
- Quick actions for student, infraction, suspension, referral, positive behaviour and reports.
- Positive Behaviour page with recognition records.
- Positive behaviour records stored in Supabase with RLS and audit logging.
- Student profiles with private photo storage and signed URLs.
- Dean-only staff account management and audit log.
- Online/offline PWA data cache and queued record synchronization.
- CSV reporting with positive behaviour counts.

## Supabase project
Project ref: `hwggkvmeqkbenjwvsxrp`

The frontend contains only the Supabase publishable key. The service-role key is not placed in the client.

## Production note
The Vercel connector currently does not expose an authorized team/project in this session, so this package is ready for deployment but no live Vercel URL is claimed here.

## Security
Supabase security advisory currently reports only the existing warning that leaked-password protection is disabled. Enable leaked-password protection in Supabase Auth settings before production rollout.
